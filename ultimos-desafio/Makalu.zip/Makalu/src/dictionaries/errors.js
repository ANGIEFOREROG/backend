export default {
  MONGOOSE_VALIDATION: "M001",
};
