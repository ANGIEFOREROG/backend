export default {
  WELCOME: "welcome",
  RESTORE_PWD: "restorePwd",
  PURCHASE: "purchase",
};
